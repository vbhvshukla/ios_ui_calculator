package com.example.firebasetut

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
