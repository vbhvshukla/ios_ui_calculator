import 'package:flutter/material.dart';
const Color KGrayColor = Colors.grey;
const Color KGreen = Colors.green;
const Color WhiteColor = Colors.white;